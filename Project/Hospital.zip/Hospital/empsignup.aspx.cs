﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class empsignup : System.Web.UI.Page

{

    SqlConnection con = new SqlConnection("Data Source=DELL-PC; Initial Catalog=Hospitalmanagement; Integrated Security=true");
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void subbtn_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "sp_hospital_empsignup";
        cmd.Connection = con;

        SqlParameter p = new SqlParameter("@name", SqlDbType.VarChar, 20);
        p.Value = nametxt.Text;
        cmd.Parameters.Add(p);

        SqlParameter p1 = new SqlParameter("@loginid", SqlDbType.VarChar, 20);
        p1.Value = lidtxt.Text;
        cmd.Parameters.Add(p1);

        SqlParameter p2 = new SqlParameter("@password", SqlDbType.VarChar, 20);
        p2.Value = pwdtxt.Text;
        cmd.Parameters.Add(p2);

        SqlParameter p3 = new SqlParameter("@department", SqlDbType.VarChar, 20);
        p3.Value = depddl.Text;
        cmd.Parameters.Add(p3);

        SqlParameter p4 = new SqlParameter("@phonenumber", SqlDbType.BigInt);
        p4.Value = phtxt.Text;
        cmd.Parameters.Add(p4);

        SqlParameter p5 = new SqlParameter("@address", SqlDbType.VarChar, 20);
        p5.Value = addtxt.Text;
        cmd.Parameters.Add(p5);

        SqlParameter p6 = new SqlParameter("@email", SqlDbType.VarChar, 20);
        p6.Value = emtxt.Text;
        cmd.Parameters.Add(p6);

        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("emplogin.aspx");
    }
    protected void Resbtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("empsignup.aspx");
    }
    protected void canbtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("emplogin.aspx");
    }
}