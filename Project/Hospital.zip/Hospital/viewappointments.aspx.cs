﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class viewappointments : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=DELL-PC; Initial Catalog=Hospitalmanagement; Integrated Security=true");
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            filldrop();
            doctorddl.Items.Insert(0, "...Select...");
        }
    }
    void filldrop()
    {
        con.Open();
        string qry = "select name from hospital_doctorsignup";
        SqlDataAdapter da = new SqlDataAdapter(qry, con);
        DataSet ds = new DataSet();
        da.Fill(ds, "hospital_doctorsignup");
        doctorddl.DataSource = ds;
        doctorddl.DataTextField = "name";
        doctorddl.DataBind();
        con.Close();

    }

    protected void doctorddl_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
    protected void appbtn_Click(object sender, EventArgs e)
    {
        con.Open();
        //string str = doctorddl.SelectedItem.ToString();
        string qry = "select * from hospital_patientinfo where doctor='" + doctorddl.SelectedValue + "' ";
        SqlDataAdapter da = new SqlDataAdapter(qry, con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        con.Close();
    }
    protected void backbtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("doctorsden.aspx");
    }
}